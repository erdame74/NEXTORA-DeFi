const rates={1:.65,7:.75,15:.85,30:1};
const $=s=>document.querySelector(s);
const money=n=>new Intl.NumberFormat('en-US',{style:'currency',currency:'USD'}).format(n);
function calc(){let amount=Math.min(1000,Math.max(20,Number($('#amount').value)||20));let days=Number($('#days').value);let profit=amount*(rates[days]/100)*days;$('#amount').value=amount;$('#capital').textContent=money(amount);$('#profit').textContent=money(profit);$('#total').textContent=money(amount+profit)}
$('#amount').addEventListener('input',calc);$('#days').addEventListener('change',calc);
document.querySelectorAll('.select').forEach(b=>b.addEventListener('click',()=>{$('#days').value=b.dataset.days;calc();location.hash='calculadora';toast(`Plan de ${b.dataset.days} día(s) seleccionado`)}));
function toast(t){let x=$('#toast');x.textContent=t;x.classList.add('show');setTimeout(()=>x.classList.remove('show'),2300)}
$('#connectBtn').addEventListener('click',()=>toast('Conexión de billetera disponible en la siguiente integración.'));
$('#copyRef').addEventListener('click',async()=>{try{await navigator.clipboard.writeText($('#refCode').textContent);toast('Código copiado')}catch{toast('Código: NEXTORA-DEMO')}});
document.querySelectorAll('[data-action]').forEach(b=>b.addEventListener('click',()=>{if(b.dataset.action==='deposit')toast(`Depósito ${b.dataset.network}: módulo de pago pendiente de integración.`);else toast('Retiro: módulo de pago pendiente de integración.')}));calc();